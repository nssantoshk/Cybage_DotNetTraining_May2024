﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1_EFExample1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /// Create an object of entities class
            CybageForPracticeEntities entityObject=
                new CybageForPracticeEntities();


            /// Read all the contents of the table
            var allRecords=
                from record in entityObject.CybagePersonDetails
                select record;

            foreach (var record in allRecords)
            {
                Console.WriteLine("{0}\t{1}",
                    record.Id,
                    record.Name
                    );
            }


        }
    }
}
