﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ConsoleApp_SampleEFExample
{
    internal class CybagePerson
    {
        [Key]
        public int PersonId { get; set; }
        public String? PersonName { get; set; }
        public int PersonAge { get; set; }
        public String? PersonResidingCityName { get; set; }
    }
}
