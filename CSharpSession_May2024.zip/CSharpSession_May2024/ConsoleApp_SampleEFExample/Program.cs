﻿namespace ConsoleApp_SampleEFExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            using(var dbObject=new AppDbContext())
            {
                dbObject.Database.EnsureCreated();
                dbObject.People.Add(new CybagePerson()
                {
                    PersonAge = 23,
                    PersonId = 1,
                    PersonName = "Jojo",
                    PersonResidingCityName = "Delhi"
                });
                dbObject.SaveChanges();
            }
        }
    }
}
