﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_SampleEFExample
{
    internal class AppDbContext:DbContext
    {
        public DbSet<CybagePerson> People { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Data Source=NSSANTOSHK-W10;Initial Catalog=CybageForPractice;Integrated Security=True;Encrypt=False");
        }
    }
}
