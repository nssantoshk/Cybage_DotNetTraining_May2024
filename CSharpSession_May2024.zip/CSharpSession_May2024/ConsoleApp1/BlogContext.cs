﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class BlogContext:DbContext
    {
        public DbSet<Blog> MyBlogs { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=NSSANTOSHK-W10;Initial Catalog=CybageForPractice;Integrated Security=True;Encrypt=False;Trust Server Certificate=True");
        }
    }
}
