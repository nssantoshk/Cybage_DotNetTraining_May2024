﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Code First Approach in EF Core");
            BlogContext contextObject= new BlogContext();
            var allBlogData=from blogObject in contextObject.MyBlogs
                            select blogObject;

            foreach (var blog in allBlogData)
            {
                Console.WriteLine(blog.BlogId + blog.BlogName +
                    blog.BlogContent);
            }
            //Blog blogObject =
            //    new Blog()
            //    {
            //        BlogContent = "Dummy Content for the blog1",
            //        BlogName = "First Blog at Cybage"
            //    };
            //contextObject.MyBlogs.Add(blogObject);
            //contextObject.SaveChanges();
            //Console.WriteLine("New Blog Added Successfully");
        }
    }
}
