﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Blog
    {
        [Key]
        public int BlogId { get; set; }
        public String? BlogName { get; set; }
        public String? BlogContent { get; set; }
    }
}
