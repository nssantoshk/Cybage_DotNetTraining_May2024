﻿using System;
using System.Collections.Generic;

namespace ConsoleApp3;

public partial class CybagePersonDetail
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? Address { get; set; }

    public string? Gender { get; set; }

    public string? Picture { get; set; }
}
