﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class EmailCommunication : ISendMessage
    {
        public void SendYourMessage(string message)
        {
            Console.WriteLine("Following message : {0}\n of yours will be sent via email",
                message);
        }
    }
}
