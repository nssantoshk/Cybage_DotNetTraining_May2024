﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Communicate
    {
        private ISendMessage? messagingObject;
        public Communicate(ISendMessage? messagingObject)
        {
            this.messagingObject = messagingObject;
        }
        public void CommunicateWithUsers(String? messageToBePassed)
        {
            this.messagingObject.SendYourMessage(messageToBePassed);
        }
    }
}
