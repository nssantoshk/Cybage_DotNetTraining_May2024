﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            /// Scenario 1
            /// 
            EmailCommunication commObject= new EmailCommunication();
            String? mycustommessage = "This is C# discussion class";
            Communicate communicateObject =
                new Communicate(commObject);

            communicateObject.CommunicateWithUsers(mycustommessage);

            /// Scenario 2
            ISendMessage messagingObject;
            mycustommessage = "We are working with the Dependency Injection";
            messagingObject = new SMSCommunication();
            communicateObject= new Communicate(messagingObject);

        }
    }
}
