﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private DemoEmpContext _demoEmpContext;
        public HomeController()
        {
            this._demoEmpContext =
                new DemoEmpContext("Data Source=NSSANTOSHK-W10;Initial Catalog=CybageForPractice;Integrated Security=True;Encrypt=False;");
        }
        // GET: Home
        public ActionResult Index()
        {
            var allRecords=
                from record in this._demoEmpContext.DemoEmps
                select record;
            return View(allRecords.ToList());
        }
    }
}