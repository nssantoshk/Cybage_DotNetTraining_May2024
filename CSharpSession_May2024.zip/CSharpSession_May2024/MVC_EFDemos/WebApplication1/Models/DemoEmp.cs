﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class DemoEmp
    {
        [Key]
        public int EmpId { get; set; }
        public String EmpName { get; set; }
        public int EmpAge { get; set; }
        public String EmpCity { get; set; }
    }
}