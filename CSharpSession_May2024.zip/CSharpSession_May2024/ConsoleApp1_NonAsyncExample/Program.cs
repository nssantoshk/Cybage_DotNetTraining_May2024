﻿namespace ConsoleApp1_NonAsyncExample
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Task taskObject1 = Fun1();
            Task taskObject = Fun();
            
            await taskObject1;
            await taskObject;
        }
        static async Task Fun()
        {
            await Task.Delay(10000);
            Console.WriteLine("Hello from Fun method");
        }
        static async Task Fun1()
        {
            await Task.Delay(12000);
            Console.WriteLine("Welcome from Fun1 method");
        }
    }
}
