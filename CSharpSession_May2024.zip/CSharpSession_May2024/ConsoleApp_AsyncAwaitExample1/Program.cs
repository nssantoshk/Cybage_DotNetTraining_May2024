﻿namespace ConsoleApp_AsyncAwaitExample1
{
    public delegate void DemoDelegate();
    internal class Program
    {
        static async Task Main(string[] args)
        {
            await Task.Delay(9000);
              Console.WriteLine("Hello, World!");
            

            
            Task task1 = Fun();
            Task task2= Fun1();
            await task1;
            await task2;
        }

        static async Task Fun()
        {
            await Task.Delay(5000);
            Console.WriteLine("Hello from Fun method");
        }

        static async Task Fun1()
        {
            await Task.Delay(3000);
            Console.WriteLine("Welcome from Fun1 method");
        }
    }
}
