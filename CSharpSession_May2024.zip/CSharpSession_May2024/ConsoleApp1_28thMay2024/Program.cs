﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1_28thMay2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //CybageDept deptObject = new CybageDept()
            //{
            //    DepartmentName = "IT",
            //    DepartmentLocation = "Bengaluru"
            //};

            //CybageDept deptObject = new CybageDept();

            //Console.WriteLine("Enter Name of the department");
            //deptObject.DepartmentName = Console.ReadLine();

            //Console.WriteLine("Enter Location of the department");
            //deptObject.DepartmentLocation = Console.ReadLine();

            DataClasses1DataContext dcContext=new DataClasses1DataContext();

            //dcContext.CybageDepts.InsertOnSubmit(deptObject);
            // dcContext.SubmitChanges();

            //Console.WriteLine("Record Added Successfully");

            //var deptObj=(from deptRecord in dcContext.CybageDepts
            //             where deptRecord.DepartmentId==10
            //             select deptRecord).SingleOrDefault();

            //CybageEmp empObject = new CybageEmp()
            //{
            //    EmployeeName = "Jojo",
            //    EmployeeDepartment = deptObj.DepartmentId,
            //    EmployeeGender = "Male",
            //    CybageDept = deptObj,
            //    EmployeeSalary = 5000
            //};


            //dcContext.CybageEmps.InsertOnSubmit(empObject);
            //dcContext.SubmitChanges();

            //Console.WriteLine("Record of Employee Added Successfully");


            //var allRecords =
            //    from empRecord in dcContext.CybageEmps
            //    join deptRecord in dcContext.CybageDepts
            //    on empRecord.EmployeeDepartment equals
            //    deptRecord.DepartmentId
            //    select new
            //    {
            //        DepartmentName = deptRecord.DepartmentName,
            //        DepartmentLocation = deptRecord.DepartmentLocation,
            //        EmployeeName = empRecord.EmployeeName,
            //        Salary = empRecord.EmployeeSalary
            //    };

            //foreach (var record in allRecords)
            //{
            //    Console.WriteLine("{0}\t{1}\t{2}\t{3}",
            //        record.DepartmentName,
            //        record.DepartmentLocation,
            //        record.EmployeeName,
            //        record.Salary);
            //}


            var empRecord = dcContext.CybageEmps.SingleOrDefault(record => record.EmployeeId == 1);

            empRecord.EmployeeGender = "Male";
            empRecord.EmployeeSalary = 17000;

            dcContext.SubmitChanges();
























        }
    }
}
